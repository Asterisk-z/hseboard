<?php

namespace App\Http\Controllers;

use App\Models\PermitToWorkReminder;
use Illuminate\Http\Request;

class PermitToWorkReminderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PermitToWorkReminder  $permitToWorkReminder
     * @return \Illuminate\Http\Response
     */
    public function show(PermitToWorkReminder $permitToWorkReminder)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PermitToWorkReminder  $permitToWorkReminder
     * @return \Illuminate\Http\Response
     */
    public function edit(PermitToWorkReminder $permitToWorkReminder)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PermitToWorkReminder  $permitToWorkReminder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PermitToWorkReminder $permitToWorkReminder)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PermitToWorkReminder  $permitToWorkReminder
     * @return \Illuminate\Http\Response
     */
    public function destroy(PermitToWorkReminder $permitToWorkReminder)
    {
        //
    }
}
